# Documentation

This folder contains documentation, resources, and downloadable materials for the AHFJCPI website.

## Contents:

- Study guides
- Sermon notes
- Teaching materials
- Prayer guides
- Discipleship resources
- Other church documents

## File Organization:

Place PDF files and other downloadable resources here, organized by category if needed.
