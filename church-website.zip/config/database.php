<?php
/**
 * AHFJCPI Database Configuration
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database configuration
// INSTRUCTIONS: After creating your InfinityFree account:
// 1. Replace these values with your InfinityFree database credentials
// 2. Get them from: Control Panel > MySQL Databases

// For local development (current setup)
// define('DB_HOST', 'localhost');
// define('DB_NAME', 'ahfjcpi_db');
// define('DB_USER', 'root');
// define('DB_PASS', '');

// For InfinityFree hosting
define('DB_HOST', 'sql210.infinityfree.com');
define('DB_NAME', 'if0_41033448_ahfjcpi');
define('DB_USER', 'if0_41033448');
define('DB_PASS', 'Cmtorres1324');

define('DB_CHARSET', 'utf8mb4');

try {
    // Create PDO connection
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
} catch (PDOException $e) {
    // Log error and show user-friendly message
    error_log("Database Connection Error: " . $e->getMessage());
    
    // Check if database doesn't exist
    if ($e->getCode() == 1049) {
        die("Database not found. Please run the setup SQL script first.");
    }
    
    die("Database connection failed. Please check your configuration.");
}

// Helper function to get PDO connection
function getDB() {
    global $pdo;
    return $pdo;
}
